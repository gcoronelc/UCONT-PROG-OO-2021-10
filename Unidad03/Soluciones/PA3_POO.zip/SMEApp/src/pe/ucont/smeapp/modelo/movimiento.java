/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.ucont.smeapp.modelo;

/**
 *
 * @author JOSEFDELL
 */
public class movimiento {
private long idmovimiento; 	
private long idcuenta;    	
private String idtipomovimiento;
private long idcajero;        
private double importe;     	
    
}
