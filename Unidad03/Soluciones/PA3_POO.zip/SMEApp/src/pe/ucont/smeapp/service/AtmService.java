package pe.ucont.smeapp.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import pe.ucont.smeapp.db.AccesoDB;

/*
Desarrollado por: Jose Luis Flores Grovas
 */
public class AtmService {

    public boolean validaAcceso(long idcuenta, long nip) {
        Connection cn = null;
        boolean accesoCorrecto = false;
        try {
            cn = AccesoDB.getConnection();
            String query = "Select idcuenta from cuenta where idcuenta = " + "?" + " and nip = " + "?";
            PreparedStatement pstm = cn.prepareStatement(query);
            //System.out.println("Acceso query: " + query);
            pstm.setLong(1, idcuenta);
            pstm.setLong(2, nip);
            ResultSet rs = pstm.executeQuery();
            if (rs.next()) {
                System.out.println("Acceso exitoso");
                accesoCorrecto = true;
            } else {
                System.out.println("datos incorrectos");
                accesoCorrecto = false;
            }
            rs.close();
            pstm.close();
            cn.close();
        } catch (SQLException e) {
            //propagamos el error a la capa siguente
            throw new RuntimeException(e.getMessage());
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                }
            } catch (SQLException e) {
                throw new RuntimeException(e.getMessage());
            }

        }
        System.out.println("return accesoCorrecto");
        return accesoCorrecto;
    }

    public double obtenerSaldo(long idcuenta) {
        //saldo= Math.round(saldo,2);
        double saldo = 0;
        Connection cn = null;
        try {
            cn = AccesoDB.getConnection();
            String query = "Select saldo from cuenta where idcuenta = " + "?";
            PreparedStatement pstm = cn.prepareStatement(query);
            pstm.setLong(1, idcuenta);
            ResultSet rs = pstm.executeQuery();
            System.out.println(query);
            while (rs.next()) {
                saldo = rs.getDouble("saldo");
                System.out.println("devuelve el saldo");
            }
            rs.close();
            pstm.close();
            cn.close();
        } catch (SQLException e) {
            //propagamos el error a la capa siguente
            throw new RuntimeException(e.getMessage());
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                }
            } catch (SQLException e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return saldo;
    }

    public boolean realizarDeposito(long idcuenta, long idcajero, double valor) {
        if (realizarMovimiento(idcuenta, "D",  idcajero, valor) == false) {
            throw new RuntimeException("Error al realizar el depósito.");
        }
        return true;
    }

    public boolean realizarRetiro(long idcuenta, long idcajero, double valor) {
        if (realizarMovimiento(idcuenta, "R", idcajero, valor * -1) == false) {
            return false; //no hay saldo
        } //propagamos el error a la capa siguente
        return true;
    }

    /*
    Este proceso realiza cualquier tipo de movimiento puedes ser deposito, retiro, cargos, intereses, etc.
     */
    public boolean realizarMovimiento(long idcuenta, String idtipoMovimiento, long idcajero, double valor) {
        //saldo += valor;
        int nregistroactualizado = 0;
        double saldo = 0;
        //primero se valida el saldo antes de realizar la transaccion 
        try {
            saldo = obtenerSaldo(idcuenta);
            saldo += valor; //siempre suma, si el valor es positivo suma, si el valor es negativo, resta.
            System.out.println("saldo:" + saldo);
            if (saldo < 0 && idtipoMovimiento == "R") {
                System.out.println("devuelve falso porque no hay saldo" );
                return false; //no dispone de saldo
            }

        } catch (Exception e) {
            throw new RuntimeException(e.getMessage() );
        }
        //System.out.println("inicia la conexion para realizar el movimiento.");
        Connection cn =null;
        try {
            cn = AccesoDB.getConnection();
            //System.out.println("luego de la conexion para realizar el movimiento.");
            //System.out.println("inicia transaccion.");
            cn.setAutoCommit(false); //iniciamos la transaccion porque vamos a insertar un movimiento en una table y actualizar el saldo en otra tabla.
            String query = "insert into movimiento(idmovimiento, idcuenta, idtipomovimiento, idcajero, importe) values ( sec_movimiento.nextval, "+"?"+","+ "?"+ "," +"?"+","+ "?"+")";
            PreparedStatement pstm = cn.prepareStatement(query);
            pstm.setLong(1, idcuenta);
            pstm.setString(2, idtipoMovimiento); //Depósito, Retiro, Cargos, Intereses, ETC.
            pstm.setLong(3, idcajero);
            pstm.setDouble(4, valor);
            nregistroactualizado = pstm.executeUpdate();
            //System.out.println("luego de ejecutar executeUpdate().");
            if (nregistroactualizado == 0) {
                cn.rollback();
                throw new RuntimeException("Error al registrar el movimiento");
            }
            pstm.close();
            //actualizamos el saldo de la cuenta
            query = "update cuenta set saldo = " + "?" + " where idcuenta = " + "?";
            PreparedStatement pstmSaldo = cn.prepareStatement(query);
            pstmSaldo.setDouble(1, saldo);
            pstmSaldo.setLong(2, idcuenta);
            nregistroactualizado = pstmSaldo.executeUpdate();
            if (nregistroactualizado == 0) {
                cn.rollback();
                throw new RuntimeException("Error al actualizar el saldo");
            }
            pstmSaldo.close();
            System.out.println(query);
            cn.commit();
            cn.close();
        } catch (SQLException e) {
            if (cn != null) {
                System.out.println("Rollback");
                try {
                    //deshace todos los cambios realizados en los datos
                    cn.rollback();
                } catch (SQLException ex) {
                    System.err.println("No se pudo deshacer" + ex.getMessage());
                    throw new RuntimeException(ex.getMessage());
                }
            }
            //propagamos el error a la capa siguente
            throw new RuntimeException(e.getMessage());
        } finally {
            try {
                cn.close();
            } catch (SQLException e) {
                throw new RuntimeException(e.getMessage());
                //return false;
            }
        }
        return true;
    }
}
