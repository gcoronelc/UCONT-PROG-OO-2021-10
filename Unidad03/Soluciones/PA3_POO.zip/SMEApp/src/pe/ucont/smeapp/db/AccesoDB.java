/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.ucont.smeapp.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author JOSEFDELL
 */
public class AccesoDB {
    //colocamos private al constructor para que no se creen instancias
    private AccesoDB() {
    }
    
    

public static Connection getConnection () throws SQLException{
    Connection cn = null; //conexion con la base de datos
    try{
        Class.forName("oracle.jdbc.OracleDriver").newInstance();
         //192.168.1.3:1521 es el ip del servidor de base y puerto
         //XE: es la instancia de oracle
        String url = "jdbc:oracle:thin:@192.168.1.3:1521/XE";
        cn= DriverManager.getConnection(url , "atmpa3final2", "admin");
    }catch ( ClassNotFoundException e) {
        throw  new SQLException("No se encuentra el Driver");
    } catch (SQLException e) {
        throw e;
        
    } catch (Exception e){
        throw  new SQLException("Se ha presentado errores en la base de datos.");
    }
    //devuelve la conexión
    return cn;
}    
   
    
}