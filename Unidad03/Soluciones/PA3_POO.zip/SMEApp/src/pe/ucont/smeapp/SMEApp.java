package pe.ucont.smeapp;

import pe.ucont.smeapp.view.SMEView;

 
public class SMEApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SMEView.main(args);
    }

}
