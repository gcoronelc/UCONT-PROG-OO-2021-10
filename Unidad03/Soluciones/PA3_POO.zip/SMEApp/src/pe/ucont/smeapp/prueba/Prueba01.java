package pe.ucont.smeapp.prueba;

import pe.ucont.smeapp.service.AtmService;

/**
 */
public class Prueba01 {
    public static void main(String[] args) {
       // Variables
		 double saldo;
		 // Datos
		 // Proceso
		 AtmService service = new AtmService();
		 //obtener saldo
                 saldo = service.obtenerSaldo(12345);
                 System.out.println("saldo Inicial: " + saldo);
                 //realizar retiro
                 boolean res = service.realizarRetiro(12345, 10000, 20);
                 System.out.println("retiro: " + 20);
                 
                 saldo = service.obtenerSaldo(12345);
                 System.out.println("saldo luego del retiro:" + saldo);
		 // realizar deposito
                 boolean res2 = service.realizarDeposito(12345, 10000, 100.00);
                 System.out.println("deposito : " + 100);
                 saldo = service.obtenerSaldo(12345);
                 System.out.println("saldo luego del depósito: " + saldo);
                 

    }

}
