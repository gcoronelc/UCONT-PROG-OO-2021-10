/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.ucont.smeapp.modelo;

import java.util.List;
import oracle.sql.DATE;

/**
 *
 * @author JOSEFDELL
 */
public class persona {
    private long nip;
    private String nombre;
    private String clave;
    private DATE fechanacimiento;
    private List<cuenta> cuentas;//varias cuentas

}
