Rem Empresa        :  EGCC
Rem Software       :  Sistema de Cajero
Rem DBMS           :  Oracle
Rem Esquema        :  atm
Rem Script         :  Crea el esquema con sus respectivas tablas
Rem Responsable    :  Jose Luis Flores
Rem Creado el      :  25/04/2021


Rem ============================================
Rem DESHABILITAR SALIDAS
Rem ============================================


-- =============================================
-- CRACIÓN DEL USUARIO
-- =============================================

DECLARE
	N INT;
	COMMAND VARCHAR2(200);
BEGIN
	COMMAND := 'DROP USER ATMPA3FINAL2 CASCADE';
	SELECT COUNT(*) INTO N
	FROM DBA_USERS
	WHERE USERNAME = 'ATMPA3FINAL2';
	IF ( N = 1 ) THEN
		EXECUTE IMMEDIATE COMMAND;
	END IF;
END;
/

CREATE USER atmpa3final2 IDENTIFIED BY admin;

GRANT CONNECT, RESOURCE TO atmpa3final2;
GRANT CREATE VIEW TO atmpa3final2;


-- =============================================
-- CONECTARSE A ORACLE
-- =============================================

CONNECT atmpa3final2/admin

-- ==========================================================
-- Crear la Tabla de cajero solo con fines de saber el cajero en que se registrar el movimiento: cajero
-- ==========================================================

CREATE TABLE cajero
(
	idcajero             NUMBER(5) NOT NULL ,
	nombre               VARCHAR2(30) NULL ,
	fechainstalacion	 DATE NULL ,
	CONSTRAINT pk_cajero PRIMARY KEY ( idcajero )
);


-- ==========================================================
-- Crear la Tabla de persona que serian el ahorrista: persona
-- ==========================================================

CREATE TABLE persona (
	nip			NUMBER(5) NOT NULL,
	nombre      VARCHAR2(50) NOT NULL,
	clave		VARCHAR2(30) NOT NULL,
	fechanacimiento      DATE NULL ,
    CONSTRAINT pk_persona PRIMARY KEY ( nip )
);

-- ==========================================================
-- Crear la Tabla de cuentas bancarias: cuenta
-- ==========================================================

CREATE TABLE cuenta (
    idcuenta    NUMBER(5) NOT NULL,
	nip			NUMBER(5) NOT NULL,
    saldo		DECIMAL(12,2) NOT NULL,
	fechaemision         DATE NULL ,
    CONSTRAINT pk_cuenta PRIMARY KEY ( idcuenta),
    CONSTRAINT fk_cuenta_persona
        FOREIGN KEY ( nip ) 
        REFERENCES persona ( nip )
);

-- ==========================================================
-- Crear la Tabla de tipomovimiento: tipomovimiento
-- ==========================================================

CREATE TABLE tipomovimiento
(
	idtipomovimiento     VARCHAR2(1) NOT NULL ,
	descripcion          VARCHAR2(20) NULL ,
	CONSTRAINT pk_tipomovimiento PRIMARY KEY ( idtipomovimiento )
);


-- ==========================================================
-- Crear la Tabla de movimientos: movimiento
-- ==========================================================

CREATE TABLE movimiento (
	idmovimiento 	NUMBER  NOT NULL,
    idcuenta    	NUMBER(5) NOT NULL	,
    idtipomovimiento	VARCHAR2(1)	NOT NULL	,	-- RETIRO =R, DEPOSITO=D
	idcajero             NUMBER(5) NOT NULL ,
    importe     	DECIMAL(12,2) NOT NULL, 	--fecha                DATE NULL ,
    CONSTRAINT pk_movimiento         PRIMARY KEY ( idmovimiento ),
    CONSTRAINT fk_movimiento_cuenta 		FOREIGN KEY ( idcuenta ) 		REFERENCES cuenta ( idcuenta ),
    CONSTRAINT fk_movimiento_tipomovimiento FOREIGN KEY ( idtipomovimiento) REFERENCES tipomovimiento ( idtipomovimiento ),
    CONSTRAINT fk_movimiento_cajero  		FOREIGN KEY ( idcajero ) 		REFERENCES cajero ( idcajero )
);

 
-- ==========================================================
-- Secuencia para autoincremantar el idmovimiento: sec_movimiento
-- ==========================================================

Create sequence sec_movimiento
  start with 3
  increment by 1;
  
-- ==========================================================
-- Cargar datos a la tabla: persona
-- ==========================================================

INSERT INTO persona ( nip, nombre,clave,fechanacimiento ) VALUES ( 12345, 'Luis Joaquín Flores T.', '12345', to_date('20101106','YYYYMMDD') );

-- ==========================================================
-- Cargar datos a la tabla: cuenta
-- ==========================================================

INSERT INTO cuenta ( idcuenta, nip, saldo, fechaemision ) VALUES ( 12345, 12345, 5200.00, to_date('20210502','YYYYMMDD') );
INSERT INTO cuenta ( idcuenta, nip, saldo, fechaemision ) VALUES ( 12346, 12345, 1000.00, to_date('20210502','YYYYMMDD') );


-- ==========================================================
-- Cargar datos cajeros: cajero
-- ==========================================================

INSERT INTO cajero ( idcajero, nombre, fechainstalacion  ) VALUES ( 10000, 'Atm 2232', to_date('20200102','YYYYMMDD') );
 
 
-- ==========================================================
-- Cargar datos cajeros: cajero
-- ==========================================================

INSERT INTO tipomovimiento ( idtipomovimiento, descripcion ) VALUES ('D', 'Deposito' );
INSERT INTO tipomovimiento ( idtipomovimiento, descripcion ) VALUES ('R', 'Retiro' );
 
 

-- ==========================================================
-- Cargar datos a la tabla: movimiento
-- ==========================================================

INSERT INTO movimiento (idmovimiento, idcuenta, idtipomovimiento, idcajero, importe ) VALUES (1, 12345, 'D', 10000, 5200);


COMMIT;


